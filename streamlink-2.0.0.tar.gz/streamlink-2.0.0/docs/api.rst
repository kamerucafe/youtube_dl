API Reference
=============

.. module:: streamlink

This ia reference of all the available API methods in Streamlink.

Streamlink
------------

.. autofunction:: streams


Session
-------

.. autoclass:: Streamlink
    :members:


Plugins
-------
.. module:: streamlink.plugin
.. autoclass:: Plugin
    :members:

.. module:: streamlink.options
.. autoclass:: Arguments
    :members:

.. autoclass:: Argument
    :members:

    .. automethod:: __init__


Streams
-------

All streams inherit from the :class:`Stream` class.

.. module:: streamlink.stream
.. autoclass:: Stream
    :members:


Stream subclasses
^^^^^^^^^^^^^^^^^

You are able to inspect the parameters used by each stream,
different properties are available depending on stream type.

.. autoclass:: AkamaiHDStream
    :members:

.. autoclass:: HDSStream
    :members:

.. autoclass:: HLSStream
    :members:

.. autoclass:: HTTPStream
    :members:

.. autoclass:: RTMPStream
    :members:

.. autoclass:: DASHStream
    :members:


Exceptions
----------

Streamlink has three types of exceptions:

.. autoexception:: streamlink.StreamlinkError
.. autoexception:: streamlink.PluginError
.. autoexception:: streamlink.NoPluginError
.. autoexception:: streamlink.StreamError
